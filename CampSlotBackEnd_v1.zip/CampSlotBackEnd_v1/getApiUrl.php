<?php 
    echo json_encode(array("apiUrl"=>"http://h96046yr.beget.tech/campSlot/"));
?>